from setuptools import setup, find_packages


setup(
    name="scbd",
    packages=find_packages(),
    install_requires=[
        "lightning==2.4.0",
        "lmdb==1.5.1",
        "matplotlib==3.9.2",
        "pandas==2.2.3",
        "pyarrow==17.0.0",
        "seaborn==0.13.2",
        "scikit-learn=1.5.2",
        "torch==2.4.1",
        "torchvision==0.19.1",
        "wilds==2.0.0"
    ]
)