import numpy as np


UINT8_MAX = np.iinfo(np.uint8).max
UINT16_MAX = np.iinfo(np.uint16).max
UINT32_MAX = np.iinfo(np.uint32).max