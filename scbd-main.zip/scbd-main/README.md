# Supervised Contrastive Block Disentanglement (SCBD)

## Installation

1. Create a virtual environment with Python 3.11.
2. `cd scbd`
3. `pip install -e .`

## Usage

### Train the model

    SEED=0
    
    python main.py \
    --dataset funk22 \
    --data_dpath $DATA_DPATH \
    --results_dpath results \ 
    --seed $SEED

By default, the model trains indefinitely and checkpoints every epoch.

### Save the embeddings from the trained model

Specifying `data_split` tells the model to run in test mode and save the embeddings. It is important to set `results_dpath` 
to a unique value for each split. Due to memory constraints, we save the embeddings every `steps_per_embed` steps.

Each embedding file consists of `(df, zy, ze)`, where `df` is the metadata. See `batch_effects.get_embed` for an example 
of how we load and concatenate the embeddings, and merge them with CellProfiler embeddings.

    SEED=0
    
    for DATA_SPLIT in train val test
    do
    python main.py \
    --dataset funk22 \
    --data_split $DATA_SPLIT \
    --data_dpath $DATA_DPATH \
    --results_dpath results/data_split=$DATA_SPLIT \
    --ckpt_fpath results/version_$SEED/checkpoints/best.ckpt
    done

### Use the embeddings to evaluate batch prediction and CORUM

    SEED=0
    
    python batch_prediction.py \
    --results_dpath results/version_$SEED \
    --train_embed_path results/data_split=$DATA_SPLIT/version_$SEED \
    --val_embed_path results/data_split=$DATA_SPLIT/version_$SEED \
    --test_embed_path results/data_split=$DATA_SPLIT/version_$SEED \
    --cellprofiler_fpath cellprofiler_128pc.parquet

    python corum.py \
    --results_dpath results/version_$SEED \
    --train_embed_path results/data_split=$DATA_SPLIT/version_$SEED \
    --val_embed_path results/data_split=$DATA_SPLIT/version_$SEED \
    --test_embed_path results/data_split=$DATA_SPLIT/version_$SEED \
    --cellprofiler_fpath cellprofiler_128pc.parquet \
    --corum_fpath CORUM_clusters.tsv

## Adding datasets

There are three important considerations when adding datasets.

### 1. Defining the batch variable `e`

Our model uses three observed variables:
1. `x`: image
2. `y`: perturbation label
3. `e`: batch label

The user defines `e`. For Funk22, we define it as the plate and well. 

### 2. Image preprocessing

Our model uses a Gaussian likelihood for `p(x|zy,ze)` (`model_utils.GaussianNet`). Since it uses a `tanh` 
activation function for the mean of the distribution, the images `x` must be preprocessed to be in the range `[-1, 1]`.

For reference, here is the preprocessing for Funk22. The original image values are in `[0, 65535]` (i.e. uint16) 
with an extreme right skew.
1. We apply `torch.arcsinh` to reduce the skew, and the resulting images approximately 
have mean `7` and standard deviation `7`.
2. We standardize the images by subtracting `7` and dividing by `7`.

This constrains the images in Funk22 to lie in `[-1, 1]`, but **this must be verified for additional datasets in consideration**.

If it is difficult to constrain the range to `[-1, 1]`, both `forward` and `generate` in `model_utils.GaussianNet` should be 
changed to the identity function. This should not affect training, but will affect the plotting of generated images. Since 
we plot the output of `generate` which are now real-valued instead of in `[0, 1]`, pyplot will apply a per-example 
min/max scaling which may be undesirable.

### 3. Data loading

The dataloader's `__getitem__` should return:
1. A single image `x` as a float32 torch tensor
2. A single row of a pandas dataframe with at least two int64 columns: `y` (perturbation label) and `e` (batch label)

These are combined into a batch in `utils.nn_utils.collate`.

The data module requires a `get_data` function that returns the train, val, and test dataloaders, as well as a dictionary 
with `y_size` (cardinality of `y`) and `e_size` (cardinality of `e`).

### 4. Hyperparameter tuning

The default hyperparameters are effective for Funk22. For a new dataset, start with `alpha=0`, and tune the learning rate 
until the validation loss steadily decreases throughout training. Then increase `alpha` until `val_f1_score_e_zc` stops 
increasing throughout training.

## Support

Please contact Taro Makino (taro@nyu.edu) or Romain Lopez (lopez.romain@gene.com).